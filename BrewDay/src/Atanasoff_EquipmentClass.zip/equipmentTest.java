import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class equipmentTest {
	private static Equipment equipment = new Equipment(0);
	@Before
	public void setUp() throws Exception {
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testAddCapacity() {
		equipment.addCapacity((float) 2.0);
		equipment.addCapacity((float) 3.0);
		assertEquals(5, equipment.getCapacity(),0.001);
	}

	@Test
	public void testSubtractCapacity() {
		equipment.addCapacity((float) 3.0);
		equipment.subtractCapacity((float)1.2);
		assertEquals(1.8, equipment.getCapacity(),0.001);
	}

	@Test
	public void testUpdateCapacity() {
		equipment.addCapacity((float) 3.0);
		equipment.updateCapacity((float)4.0);
		assertEquals(4.0, equipment.getCapacity(),0.001);
	}

}
